<?php $__env->startSection('content'); ?>
<h1>Display Images</h1>

<?php echo Form::open(['id' => 'formBread']); ?><!-- 'route' => 'ss', 'method' => 'POST' -->
    <div class="form-group well">
       <input type="hidden" value="" id="hiddenVal" name="formtype" />
      <?php echo e(Form::label('bread', 'Bread Name')); ?>


      <?php echo e(Form::select('breadselect', $data, 'S',['class' => 'form-control','style'=>'width:10%','id' => 'breadname'])); ?>

      <?php echo e(Form::label('subbread', 'Sub Bread Name')); ?>

      <?php echo e(Form::select('subbreadselect', [''], 'S',['class' => 'form-control','style'=>'width:10%', 'id'=>'subbread' ])); ?>

    </div>
    <?php echo e(csrf_field()); ?>

    <div>
      <?php echo e(Form::button('Bread Display', ['class' => 'btngetData btn btn-primary', 'id' => 'breadlistclick' ,'data-val' => '0'])); ?>

      <?php echo e(Form::button('Rendom', ['class' => 'btngetData btn btn-primary' ,'data-val' => '1'])); ?>

    </div>
     <section class="results" id="products">
          <h4> Your Selected Bread :
                <label id="dispUrl"></label>
          </h4>
          <img src="" class="results-img" alt="placeholder" width="500" id="breadDisp" />
        </section>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
<script>
    $(document).ready(function(){
    
         $('#breadname').change(function(){

        var selectedValue = $('#breadname').val();
         var dependent=$('#breadname').data('dependent');
         var _token=$('input[Name="_token"]').val();

        $.ajax({
          url:"<?php echo e(route('homecontroller.fetch')); ?>",
          method:"POST",
          data:{ selectedValue:selectedValue ,dependent:dependent, _token:_token },
          success:function(result)
          {
            $('#subbread').html(result);
          }

        })
      });

      $('.btngetData').click(function(){

        var c_val=$(this).attr('data-val');
        $('#hiddenVal').val(c_val);

        $.ajax({
          type: "POST",
          url: "<?php echo e(route('homecontroller.submitcall')); ?>",
          data: $("#formBread").serialize(), // serializes the form's elements.
          success: function( data )
          {
            $('#dispUrl').html(data);
             $('#breadDisp').attr('src',data);
          }
        });
      });
  })

</script> 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>