<!DOCTYPE html>
<html>
<head>
	<title>Ecoserv</title>
	<link rel="stylesheet" type="text/css" href="/css/app.css">
</head>
<body>
		<?php echo $__env->yieldContent('content'); ?>
</body>
</html>