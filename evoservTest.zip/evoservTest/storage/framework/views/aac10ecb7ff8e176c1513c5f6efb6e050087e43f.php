<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Ecoserv Test</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <div class="flex-center">
        <h1>Display Dog Images</h1>
          

            <form id="formbread" action="/">
                <input name=""/>
            <input type="hidden" value="" id="hiddenVal" name="data[formtype]" />

         

            <div class="subBread">
               <label for="breed">Sub Breed</label>
              <select id="SubBreadSelect" style="vertical-align: middle; margin: 0 .5rem;padding: 0 .5rem; background-color: #fff; font-size: 1.2rem;text-transform: capitalize;" >
              
              </select>
            </div>
            <input type="button" data-val='0' class='btngetdata' value="BreedImages" >
            <input type="button" data-val='1' class='btngetdata' value="Rendom" >
            <!-- <input type="button" data-val='2' class='btngetdata' value="Select Sub Bread"> -->
          
       </form>
        <section class="results" id="products">
          <h4> Your Selected Bread :</h4>
          <img src="" class="results-img" alt="placeholder" width="500"  hei/>
        </section>
    </div>

    
    </body>
</html>
