<?php

namespace App\Http\Controllers;

//use App\Http\Controllers\Controller;	
use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Http;
use GuzzleHttp\Client;

class HomeController extends Controller
{
    public function index(){
    		

		$client = new Client();
    	$response = $client->request('GET', 'https://dog.ceo/api/breeds/list/all');
    	

    	$data=array();
    	$data=json_decode($response->getBody(),true);

    	$allData=array();
		$allData=$data['message'];
   		
   		$breadKeyval=array();
		foreach ($allData as $key => $value) {
			$breadKeyval[$key]=$key;

		}
    	return view('index',['data' => $breadKeyval]);
    }


    public function fetch(Request $request)
    {

    	$selectedValue= $request->get('selectedValue');
    	$dependent=$request->get('dependent');

    	//print_r("ccccmkmlvvm;dcvvc");die();
    	$client1 = new Client();
    	$response1 = $client1->request('GET', 'https://dog.ceo/api/breed/'.$selectedValue.'/list');
    	

    	$data1=array();
    	$data1=json_decode($response1->getBody(),true);

    	$allData1=array();
		$allData1=$data1['message'];


		$breadsubKeyval=array();
		foreach ($allData1 as $key => $value) {
			$breadsubKeyval[$value]=$value;

		}

		$output='<option value="">select '.$dependent.'</option>';
		foreach ($breadsubKeyval as $value) {
			$output .= '<option value="'.$value.'"> '.$value.'</option>';
		}

		echo $output;
    }

    public function submitcall(Request $request)
    {
    		$selectedValue= $request->all();

    		if($selectedValue['formtype'] == 0)
			{

				//print_r($selectedValue);die();
				if( $selectedValue['subbreadselect'] != 0)
				{
					//print_r($selectedValue);
					
					$imageClient = new Client();
    				$imageresponse = $imageClient->request('GET', "https://dog.ceo/api/breed/".$selectedValue['breadselect']."/".$selectedValue['subbreadselect']."/images/random");
    	

    				$imageData=array();
    				$imageData=json_decode($imageresponse->getBody(),true);

    				$imagevalue=array();
					$imagevalue=$imageData['message'];

					echo $imagevalue;

					//print_r($imagevalue);die();

				}else{
					
					$imageClient1 = new Client();
    				$imageresponse1 = $imageClient1->request('GET', "https://dog.ceo/api/breed/".$selectedValue['breadselect']."/images/random");
    	

    				$imageData1=array();
    				$imageData1=json_decode($imageresponse1->getBody(),true);

    				$imagevalue1=array();
					$imagevalue1=$imageData1['message'];
	
					echo $imagevalue1;
					//print_r($imagevalue1);die();
				}
			}else{

					$imageClientRendom = new Client();
    				$imageresponseRendom = $imageClientRendom->request('GET','https://dog.ceo/api/breeds/image/random');
    	

    				$imageDataRendom=array();
    				$imageDataRendom=json_decode($imageresponseRendom->getBody(),true);

    				$imagevalueRendom=array();
					$imagevalueRendom=$imageDataRendom['message'];

					echo $imagevalueRendom;
					//print_r($imagevalueRendom );die();
			}
			
			
    	//return view('index');
    }
}