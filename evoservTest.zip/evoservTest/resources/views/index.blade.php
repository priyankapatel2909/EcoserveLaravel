@extends('layouts.app')

@section('content')
<h1>Display Images</h1>

{!! Form::open(['id' => 'formBread']) !!}<!-- 'route' => 'ss', 'method' => 'POST' -->
    <div class="form-group well">
       <input type="hidden" value="" id="hiddenVal" name="formtype" />
      {{Form::label('bread', 'Bread Name')}}

      {{Form::select('breadselect', $data, 'S',['class' => 'form-control','style'=>'width:10%','id' => 'breadname'])}}
      {{Form::label('subbread', 'Sub Bread Name')}}
      {{Form::select('subbreadselect', [''], 'S',['class' => 'form-control','style'=>'width:10%', 'id'=>'subbread' ])}}
    </div>
    {{ csrf_field() }}
    <div>
      {{Form::button('Bread Display', ['class' => 'btngetData btn btn-primary', 'id' => 'breadlistclick' ,'data-val' => '0'])}}
      {{Form::button('Rendom', ['class' => 'btngetData btn btn-primary' ,'data-val' => '1'])}}
    </div>
     <section class="results" id="products">
          <h4> Your Selected Bread :
                <label id="dispUrl"></label>
          </h4>
          <img src="" class="results-img" alt="placeholder" width="500" id="breadDisp" />
        </section>
{!! Form::close() !!}
@endsection

<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
<script>
    $(document).ready(function(){
    
         $('#breadname').change(function(){

        var selectedValue = $('#breadname').val();
         var dependent=$('#breadname').data('dependent');
         var _token=$('input[Name="_token"]').val();

        $.ajax({
          url:"{{ route('homecontroller.fetch') }}",
          method:"POST",
          data:{ selectedValue:selectedValue ,dependent:dependent, _token:_token },
          success:function(result)
          {
            $('#subbread').html(result);
          }

        })
      });

      $('.btngetData').click(function(){

        var c_val=$(this).attr('data-val');
        $('#hiddenVal').val(c_val);

        $.ajax({
          type: "POST",
          url: "{{ route('homecontroller.submitcall') }}",
          data: $("#formBread").serialize(), // serializes the form's elements.
          success: function( data )
          {
            $('#dispUrl').html(data);
             $('#breadDisp').attr('src',data);
          }
        });
      });
  })

</script> 