<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|Route::get('/', function () {
    return view('greeting', ['name' => 'James']);
});
*/

Route::get('json-api', 'HomeController@index');

Route::get('/', function () {
    return redirect('index');
});
//Route::post('ss','HomeController@subselection');
Route::get('/index','HomeController@index');
Route::post('homecontroller/fetch','HomeController@fetch')->name('homecontroller.fetch');
//Route::post('index/submitcall','HomeController@submitcall');
Route::post('homecontroller/submitcall','HomeController@submitcall')->name('homecontroller.submitcall');